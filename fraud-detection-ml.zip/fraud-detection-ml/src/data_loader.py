import kagglehub
import os
import pandas as pd

def load_data():
    path = kagglehub.dataset_download("aliiihussain/credit-card-fraud-detection")

    for file in os.listdir(path):
        if file.endswith(".csv"):
            csv_path = os.path.join(path, file)

    df = pd.read_csv(csv_path)
    return df