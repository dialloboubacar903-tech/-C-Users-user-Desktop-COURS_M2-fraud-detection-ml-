from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier

def get_logistic():
    return LogisticRegression(class_weight="balanced", max_iter=1000)

def get_random_forest():
    return RandomForestClassifier(
        n_estimators=200,
        class_weight="balanced",
        random_state=42
    )

def get_xgboost(scale_pos_weight):
    return XGBClassifier(
        n_estimators=300,
        max_depth=6,
        learning_rate=0.05,
        scale_pos_weight=scale_pos_weight,
        eval_metric="logloss",
        random_state=42
    )