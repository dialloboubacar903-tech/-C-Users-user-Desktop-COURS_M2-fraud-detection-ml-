import optuna
from xgboost import XGBClassifier
from sklearn.metrics import roc_auc_score

def optimize_xgb(X_train, y_train, X_val, y_val):

    def objective(trial):
        param = {
            "n_estimators": trial.suggest_int("n_estimators", 100, 400),
            "max_depth": trial.suggest_int("max_depth", 3, 10),
            "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.3),
            "eval_metric": "logloss"
        }

        model = XGBClassifier(**param)
        model.fit(X_train, y_train)
        y_prob = model.predict_proba(X_val)[:,1]

        return roc_auc_score(y_val, y_prob)

    study = optuna.create_study(direction="maximize")
    study.optimize(objective, n_trials=20)

    return study.best_params