import torch
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import roc_auc_score

def train_mlp(model, criterion, X_train, y_train, X_test, y_test):

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    model.to(device)

    X_train_tensor = torch.FloatTensor(X_train)
    y_train_tensor = torch.FloatTensor(y_train.values)

    train_loader = DataLoader(
        TensorDataset(X_train_tensor, y_train_tensor),
        batch_size=1024,
        shuffle=True
    )

    optimizer = optim.Adam(model.parameters(), lr=0.001)

    for epoch in range(15):
        model.train()
        for xb, yb in train_loader:
            xb, yb = xb.to(device), yb.to(device)

            optimizer.zero_grad()
            outputs = model(xb)
            loss = criterion(outputs, yb)
            loss.backward()
            optimizer.step()

    model.eval()
    with torch.no_grad():
        X_test_tensor = torch.FloatTensor(X_test).to(device)
        y_prob = model(X_test_tensor).cpu().numpy().flatten()

    return roc_auc_score(y_test, y_prob)