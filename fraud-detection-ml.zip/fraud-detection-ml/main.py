from src.data_loader import load_data
from src.preprocessing import split_data, scale_data
from src.models_classical import get_logistic, get_random_forest, get_xgboost
from src.train_classical import train_model
from src.model_mlp import MLP
from src.focal_loss import FocalLoss
from src.train_deep import train_mlp

import numpy as np

def main():

    df = load_data()

    X_train, X_test, y_train, y_test = split_data(df)
    X_train, X_test, scaler = scale_data(X_train, X_test)

    scale_pos_weight = len(y_train[y_train==0]) / len(y_train[y_train==1])

    models = {
        "Logistic": get_logistic(),
        "RandomForest": get_random_forest(),
        "XGBoost": get_xgboost(scale_pos_weight)
    }

    for name, model in models.items():
        trained_model, cv_score = train_model(model, X_train, y_train)
        print(f"{name} CV ROC-AUC: {cv_score:.4f}")

    # Deep Learning
    mlp = MLP(X_train.shape[1])
    criterion = FocalLoss(alpha=1, gamma=2)

    mlp_auc = train_mlp(mlp, criterion, X_train, y_train, X_test, y_test)
    print("MLP + FocalLoss ROC-AUC:", mlp_auc)

if __name__ == "__main__":
    main()